# Latest release notes

This file always holds the notes for the most recent version. Per-version notes live in the `release-notes/` folder.

## Tempo 1.0.122

**New: tray sleep - a forgotten Tempo can't surprise you**
- New Behaviour option (on by default): "Sleep in tray (pause hotkeys & cursor
  trail)". While Tempo is hidden in the tray AND nothing is running, all global
  hotkeys and the hold-to-click trigger are paused and the cursor trail is hidden -
  so pressing F6 hours later in a game or document can't start invisible clicking.
- Everything wakes instantly when you open the window or start something from the
  tray menu, and the tray tooltip says "sleeping (hotkeys paused)" while it's asleep.
- It never engages while clicking, playing or recording, so "Hide window to tray
  when clicking starts" keeps working exactly as before.
- Bonus: while asleep, Tempo also skips all background UI refresh work, so an idle
  tray Tempo uses essentially no CPU.

**Settings UI**
- The Behaviour section grew a row for the new option; the groups and buttons below
  it moved down accordingly.

Windows may show "Unknown publisher" because the app isn't code-signed — click More info → Run anyway. It's safe.
